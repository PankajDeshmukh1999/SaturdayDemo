
function log(){
        var username = document.getElementById("username").value;
		var password = document.getElementById("password").value;
		// var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})$/;
		var filter = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).{5,15}$/;
        var filter2 = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/;
		if(username =='')
		{
			alert("please enter user name.");
		}
		else if(password=='')
		{
        	alert("enter the password");
		}
		else if(!filter.test(username))
		{
			alert("Enter valid email id. and length should be 7 to 15 charactors");

		 }else if(!filter2.test(password)){
			 
            alert("password should be Uppercase and Lowercase(A-Z,a-z),Numeric(0-9), and Special charactors(!@#$%^&*)")

         }
		else if(password.length < 5 || password.length > 12)
		{
			alert("Password length should be minimum 5 numbers and maximum 12 numbers");
		}
		else
		{
            alert("login success")
            console.log("User name->"+username+" Password"+password);
            
        }
}